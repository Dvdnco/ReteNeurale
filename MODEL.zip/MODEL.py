import numpy as np
import pandas as pd
from PIL import Image
from skimage import filters
import os
import pickle


data = pd.read_csv('mnist_train.csv')
data = np.array(data)
X = data[:, 1:] / 255.0
y = data[:, 0] 


n = [784, 256, 128, 64, 10] 
m = X.shape[0] 


W = [None] * len(n)
b = [None] * len(n)

def initialize_parameters():
    for i in range(len(n) - 1):
       
        W[i+1] = np.random.randn(n[i+1], n[i]) * np.sqrt(2.0/n[i])
        b[i+1] = np.zeros((n[i+1], 1))

def relu(Z):
    return np.maximum(0, Z)

def relu_derivative(Z):
    return (Z > 0).astype(float)

def softmax(Z):
    expZ = np.exp(Z - np.max(Z, axis=0, keepdims=True))
    return expZ / np.sum(expZ, axis=0, keepdims=True)

def prepara_dati(y, num_classi):
    Y = np.eye(num_classi)[y]
    return X.T, Y.T

def feed_forward(A0):
    A = [None] * len(n)
    Z = [None] * len(n)
    
    A[0] = A0
    
    for i in range(1, len(n)-1): 
        Z[i] = W[i] @ A[i-1] + b[i]
        A[i] = relu(Z[i])
  
    Z[-1] = W[-1] @ A[-2] + b[-1]
    A[-1] = softmax(Z[-1])
    
    return A[-1], A, Z

def cost(y_hat, Y):
    epsilon = 1e-15
    y_hat = np.clip(y_hat, epsilon, 1 - epsilon)
    batch_size = Y.shape[1]
    return -np.sum(Y * np.log(y_hat)) / batch_size

def backpropagation(A, Z, Y):
    dZ = [None] * len(n)
    dW = [None] * len(n)
    db = [None] * len(n)
    batch_size = Y.shape[1]

   
    dZ[-1] = A[-1] - Y
    dW[-1] = (1/batch_size) * (dZ[-1] @ A[-2].T)
    db[-1] = (1/batch_size) * np.sum(dZ[-1], axis=1, keepdims=True)

  
    for i in range(len(n)-2, 0, -1):
        dZ[i] = (W[i+1].T @ dZ[i+1]) * relu_derivative(Z[i])
        dW[i] = (1/batch_size) * (dZ[i] @ A[i-1].T)
        db[i] = (1/batch_size) * np.sum(dZ[i], axis=1, keepdims=True)

    return dW, db

def load_model(path='saved_models/model_parameters.pkl'):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Model not found at {path}")
    with open(path, 'rb') as f:
        params = pickle.load(f)
    return params['weights'], params['biases']

def preprocess_image(image_path):
    
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    
    
    img = Image.open(image_path).convert('L')
    img = img.resize((20, 20), Image.Resampling.LANCZOS)
    img_array = np.array(img)
    
    
    if np.mean(img_array) > 128:
        img_array = 255 - img_array
    

    threshold = filters.threshold_otsu(img_array)
    binary = img_array > threshold
    img_array = binary.astype(np.uint8) * 255
    
 
    output = np.zeros((28, 28), dtype=np.uint8)
    y_offset = (28 - img_array.shape[0]) // 2
    x_offset = (28 - img_array.shape[1]) // 2
    output[y_offset:y_offset + img_array.shape[0], 
           x_offset:x_offset + img_array.shape[1]] = img_array
    
  
    normalized = output.astype(float) / 255.0
    return normalized.reshape(784, 1)

def predict(image_path):
  
    global W, b
    img_input = preprocess_image(image_path)
    y_hat, _, _ = feed_forward(img_input)
    probabilities = y_hat.flatten()
    top_k = 3
    indices = np.argsort(probabilities)[-top_k:][::-1]
    confidences = probabilities[indices] * 100
    return indices, confidences

if __name__ == "__main__":
    while True:
        decisione = input("1 for training, 2 for testing, 3 to exit: ").strip()
        
        if decisione == "1":
            initialize_parameters()
            A0, Y = prepara_dati(y, n[-1])
            learning_rate = 0.01
            epochs = 300
            batch_size = 256

            n_batches = m // batch_size

            for epoch in range(epochs):
                permutation = np.random.permutation(m)
                A0_shuffled = A0[:, permutation]
                Y_shuffled = Y[:, permutation]
                
                epoch_cost = 0
                
                for batch in range(n_batches):
                    start_idx = batch * batch_size
                    end_idx = start_idx + batch_size
                    A0_batch = A0_shuffled[:, start_idx:end_idx]
                    Y_batch = Y_shuffled[:, start_idx:end_idx]
                    
                    y_hat, A, Z = feed_forward(A0_batch)
                    dW, db = backpropagation(A, Z, Y_batch)
                    
                    for i in range(1, len(n)):
                        W[i] -= learning_rate * dW[i]
                        b[i] -= learning_rate * db[i]
                    
                    epoch_cost += cost(y_hat, Y_batch)
                
                if epoch % 10 == 0:
                    print(f"Epoch {epoch}, Cost: {epoch_cost/n_batches}")

            y_hat, _, _ = feed_forward(A0)
            predictions = np.argmax(y_hat, axis=0)
            accuracy = np.mean(predictions == y)
            print(f"Final Accuracy: {accuracy * 100:.2f}%")
            
            if not os.path.exists('saved_models'):
                os.makedirs('saved_models')
            
            with open('saved_models/model_parameters.pkl', 'wb') as f:
                pickle.dump({'weights': W, 'biases': b}, f)
            print("Model saved successfully.")
        
        elif decisione == "2":
            try:
                W, b = load_model()
                image_path = input("Enter image path (e.g. digit.png): ").strip()
                if not os.path.exists(image_path):
                    print(f"Image not found: {image_path}")
                    continue
                
                digits, confidences = predict(image_path)
                print("\nTop 3 predictions:")
                for digit, conf in zip(digits, confidences):
                    print(f"Digit {digit}: {conf:.2f}% confidence")
            
            except Exception as e:
                print(f"Error during prediction: {str(e)}")
        
        elif decisione == "3":
            print("Exiting...")
            break
        
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")